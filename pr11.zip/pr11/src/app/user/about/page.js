"use client";

import { useState, useEffect, useRef } from 'react';
import styles from './page.module.css';

export default function pageUser(){

    return(
        <div>
            
        </div>
    );

}